
# Google Play 数据质量处理与应用分群

本轮范围已按10月24日任务安排确定为Google Play应用主表。入口为`run.py`，支持四类质量检查、处理计划、工具执行、复查、KMeans分群、共同记录比较、图表及日志。原始CSV保留不改。

**状态说明：** 最低必要处理和固定规则可在本地直接运行；智能体组必须配置真实API并实际运行后才算完成。查看每次输出中的`agent_status.json`；`not_configured`、`disabled`、`api_error`均不代表智能体实验完成。下面原始课程目标保留作参考，运行步骤以本节为准。

## 快速运行

要求Python 3.12及可安装的依赖。Windows PowerShell在仓库根目录执行：

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m unittest discover -s tests -v
python run.py --agent auto
```

每次运行写入新的`results/`子目录；`results/latest_run.txt`指向最近一次完整输出，原始CSV的SHA256在运行前校验。指定`--out`时目录必须为空，避免混用旧结果。真实数据的小样本检查：

精确复现本次依赖版本时，将安装命令改为`python -m pip install -r requirements.lock.txt`；实际版本也保存在每次运行清单中。

```powershell
python run.py --smoke --agent off
```

`--smoke`使用真实主表前800条和末400条（含已知错位记录），不生成正式图；不作为全量结论。主交付见`docs/戴想然_一页实现说明_1026.md`和首轮运行目录。

## 配置真实智能体

使用支持JSON对象响应的Chat Completions兼容服务。将服务商提供的API基础地址（通常以`/v1`结尾）和模型名填入终端环境变量，密钥只在本机设置。`.env.example`仅是示例，程序不会自动读取它。不要把密钥粘贴到聊天、代码、README或日志中。

```powershell
$env:LLM_BASE_URL = 'https://YOUR_PROVIDER/v1'
$env:LLM_MODEL = 'YOUR_MODEL'
# LLM_API_KEY请通过本机安全方式放入当前环境，勿提交Git。
python run.py --agent required
```

可选`LLM_INPUT_USD_PER_MILLION`及`LLM_OUTPUT_USD_PER_MILLION`由服务商实际报价填写；没报价或没usage时费用为未知。智能体只接收统计和少量样例，返回白名单JSON策略及理由；最多一次校验反馈重试，不执行模型生成的任意代码。`--agent required`在真实智能体未完成时返回退出码2，但仍保留已完成的两组基线。服务商不支持此接口或JSON模式时需调整适配器，不能用规则伪装模型响应。

## 输出与复现口径

| 文件 | 用途 |
| --- | --- |
| `quality_before.json` | 13列缺失、整行重复、异常、格式核查 |
| `minimum/`、`fixed/`、成功时的`agent/` | 清洗数据、隔离数据、变更表、分群、簇画像和代表应用 |
| `comparison.csv` | 三组状态、保留率、原生样本指标、耗时 |
| `common_metrics.csv`、`common_group_ari.csv` | 共同记录、同k=4和同变换的补充比较 |
| `common_seed_stability.csv` | 42/52/62三个种子的共同记录稳定性 |
| `shared_scaler.json` | 5个特征的统一变换参数与参考记录ID |
| `人工抽查12项_待赵思嘉复核.csv` | 原值、处理值、机器说明及留空的人工复核栏 |
| `首轮结果说明.md` | 自动生成的真实结果解释与局限 |
| `figures/图表面板.html` | 本轮9张图及来源图注，PNG和SVG均可直接使用 |
| `logs/pipeline.jsonl` | 本次真实工具、模型及复查事件 |
| `agent_status.json` | 真实模型是否调用、计划、token、费用及失败状态 |
| `run_manifest.json`、`复现清单.json` | 输入哈希、代码哈希、参数、环境版本与复现命令 |

`source_row_id`是CSV数据记录从1开始的序号，不是物理文件行号或应用唯一ID。安装量是下界；Rating缺失原因未知；Size的varies观测值保持缺失，建模代理另列。非聚类字段缺失不盲目填满。Category用于解释及可选插补，不当作真值标签。主表是历史快照，不描述2026年实时市场。

无监督指标不等于准确率；原生样本不同的轮廓系数不直接作优劣判断。共同记录为各组参与聚类ID的交集，固定k=4，记录完全相同的样本与缩放。固定规则与最低必要处理在共同完整记录上特征一致是预期现象。中位数插补的真实误差无法从该快照直接测量，明天需要人工抽查。

输入来源：[Kaggle原发布页](https://www.kaggle.com/datasets/lava18/google-play-store-apps)，SHA256：`3e438f48161961933d26e99a8d9fc8ed79edfaa9fb34f8838e1ab4ec7a9fab91`。许可及署名见`data/LICENSE.txt`与`data/数据来源说明.txt`。算法及接口核对依据：[KMeans文档](https://scikit-learn.org/stable/modules/clustering.html#k-means)、[轮廓系数文档](https://scikit-learn.org/stable/modules/generated/sklearn.metrics.silhouette_score.html)、[Chat Completions API](https://developers.openai.com/api/reference/resources/chat)。

## 原始课程目标和分工


## 1. 项目目标

设计并实现一个能够自主完成数据质量分析与预处理的数据处理智能体，并支持一个分类或聚类任务。

重点处理四类数据质量问题：缺失值、重复数据、异常值或噪声、数据类型或格式不一致。

智能体需要根据检查结果选择处理方法、调用工具完成处理，并保留处理理由、工具调用及错误修正记录，而不只是执行一套固定的清洗规则。

## 2. 数据集与任务

本轮已确定使用Google Play Store Apps主表，原始10841行、13列；不接评论表。

数据集需包含不少于 5,000 条记录、10 个字段，并至少包含以下四类问题：

缺失值。

重复数据。

异常值或噪声。

数据类型或格式不一致。

鼓励加入字段冲突、标签错误、类别不平衡、跨表实体匹配等复杂问题。

## 3. 计划工作流与实验

计划工作流：

读取数据 → 分析数据质量 → 制定处理方案 → 调用工具处理 → 检查处理结果 → 分类或聚类 → 输出结果与运行记录。


保存模型名称、提示词、参数、调用次数、成本，以及工具调用、错误和修正过程。提交前检查并移除密钥和敏感信息。

## 4. 目录规划

以下为计划结构，随开发逐步建立，不表示这些文件已经全部存在。

```text
main/
├── README.md             # 项目介绍与运行说明
├── .gitignore            # 不纳入版本管理的文件规则
├── requirements.txt      # 实现后补充实际 Python 依赖；使用其他语言时调整
├── docs/                 # 课程要求、分工、选题说明、报告、PPT、个人贡献
├── data/                 # 数据说明、允许提交的数据或样例
├── src/                  # 智能体、数据处理与分类或聚类代码
├── results/              # 对照结果、表格、图表和结果解释
└── logs/                 # 脱敏后的模型与工具运行记录
```

## 5. 小组分工

| 成员 | 主要负责 |
| --- | --- |
| 闫灿宇 | 确认选题和范围，检查首轮结果，参加最终排练 |
| 周静雯 | 跟进进度，准备数据和说明，汇总报告与 PPT |
| 戴想然 | 细化技术方案，统一对接 Codex，完成实验与演示 |
| 赵思嘉 | 整理数据处理建议，抽查处理结果，准备问答 |

这里记录的是计划分工，最终个人贡献说明按照实际完成的工作填写。

## 6. 运行说明

本轮实现入口与实际运行方法见本文件开头“快速运行”。

首轮流程跑通后补充实际环境版本、依赖安装方法、数据准备步骤、模型配置、运行命令、输出位置和复现实验方法。

## 7. 最终交付清单

- [ ] 项目报告，不超过 10 页。（注：可以绘制智能体结构图和工作流图）
- [ ] 源代码、README 和依赖文件。
- [ ] 原始及处理后的数据；无法公开时提供获取和构造方法。
- [ ] 课堂展示 PPT，汇报 7 分钟、问答 3 分钟。
- [ ] 四位成员的个人贡献说明。
- [ ] 智能体运行记录，包括提示词、工具调用、错误与修正过程。

## 报告截止日期：12-31
