"""仅对留存的后三次真实运行做离线统计；无API调用。"""
from pathlib import Path
from collections import Counter
import argparse
import csv
import hashlib
import io
import json
import math
import statistics
import sys

ROOT = Path(__file__).resolve().parent
RUN_NAMES = {2: 'run_02_attempt_01', 3: 'run_03_attempt_01', 4: 'run_04_attempt_01'}
METRICS = [
    ('cleaned_rows', '清洗档案记录数', '条'),
    ('quarantined_rows', '隔离异常记录数', '条'),
    ('exact_duplicates_removed', '去除完全重复记录数', '条'),
    ('remaining_exact_duplicates', '残留完全重复记录数', '条'),
    ('remaining_invalid_core_rows', '残留核心非法记录数', '条'),
    ('cluster_invalid_or_missing_features', '聚类非法或缺失特征记录数', '条'),
    ('cluster_rows', '聚类记录数', '条'),
    ('cluster_retention', '聚类保留率', '比例0至1'),
    ('size_imputed', '大小代理填补数', '条'),
    ('k', '选定簇数k', '个；均值仅作描述'),
    ('silhouette', '轮廓系数', '无量纲'),
    ('davies_bouldin', 'DB指数', '无量纲'),
]
POLICIES = {'deduplicate': '完全重复处理', 'rating': '评分缺失处理', 'size': '大小未观测处理'}

def jread(p):
    return json.loads(p.read_text(encoding='utf-8-sig'))

def csvread(p):
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def csvbytes(rows, fields=None):
    fields = fields or list(rows[0])
    out = io.StringIO(newline='')
    writer = csv.DictWriter(out, fieldnames=fields, lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
    return out.getvalue().encode('utf-8-sig')

def display(v):
    if isinstance(v, bool):
        return str(v).lower()
    return str(v)

def stats(values):
    values = [float(v) for v in values]
    mean = statistics.mean(values)
    variance = statistics.variance(values)
    sd = math.sqrt(variance)
    return dict(n=len(values), mean=mean, sample_variance=variance,
                sample_std=sd, min=min(values), max=max(values),
                cv_percent=100*sd/abs(mean) if mean != 0 else '')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-only', action='store_true', help='重算并比较派生文件，不写文件')
    args = parser.parse_args()
    inputs = jread(ROOT/'参照与核查/来源清单.json')
    for name, entry in inputs.items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == entry['sha256'], name
    baseline = jread(ROOT/'参照与核查/首次主实验摘要.json')
    first = baseline['agent_comparison']
    first_policy = baseline['agent_status']['validated_plan']['policy']
    audit = jread(ROOT/'参照与核查/既有四次核查记录.json')
    rows = []
    statuses = []
    for run, name in RUN_NAMES.items():
        folder = ROOT/'原始运行记录'/name
        status = jread(folder/'agent_status.json')
        manifest = jread(folder/'run_manifest.json')
        quality = jread(folder/'agent/quality_after.json')
        comparison = next(r for r in csvread(folder/'comparison.csv') if r['group'] == 'agent')
        model = jread(folder/'agent/selected_model.json')
        trace = next(t for t in audit['traces'] if t['run'] == run)
        assert status['status'] == 'completed' and status['real_model_called'] is True and status['calls'] == 1
        assert manifest['source_sha256'] == audit['source_sha256']
        assert manifest['source_code_sha256'] == audit['core_code_hashes']
        assert hashlib.sha256((folder/'run_manifest.json').read_bytes()).hexdigest() == trace['manifest_sha256']
        assert hashlib.sha256((folder/'logs/pipeline.jsonl').read_bytes()).hexdigest() == trace['trace_sha256']
        policy = status['validated_plan']['policy']
        assert policy == quality['policy']
        row = {
            'supplement_no': run-1, 'original_run': run,
            'response_id': trace['response_id'],
            'deduplicate': policy['deduplicate'], 'rating': policy['rating'], 'size': policy['size'],
            'cleaned_rows': quality['cleaned_rows'],
            'quarantined_rows': quality['quarantined_rows'],
            'exact_duplicates_removed': quality['exact_duplicates_removed'],
            'remaining_exact_duplicates': quality['remaining_exact_duplicates'],
            'remaining_invalid_core_rows': quality['remaining_invalid_core_rows'],
            'cluster_invalid_or_missing_features': quality['cluster_invalid_or_missing_features'],
            'cluster_rows': quality['cluster_rows'],
            'cluster_retention': quality['cluster_retention'],
            'rating_imputed': quality['rating_imputed'], 'size_imputed': quality['size_imputed'],
            'k': model['k'], 'silhouette': model['silhouette'], 'davies_bouldin': model['davies_bouldin'],
            'model_calls': status['calls'], 'prompt_tokens': status['prompt_tokens'],
            'completion_tokens': status['completion_tokens'],
            'total_tokens': status['prompt_tokens']+status['completion_tokens'],
            'invoice_cost_usd': status['cost_usd'],
            'reason_deduplicate': status['validated_plan']['reasons']['deduplicate'],
            'reason_rating': status['validated_plan']['reasons']['rating'],
            'reason_size': status['validated_plan']['reasons']['size']
        }
        for key in ['cluster_rows', 'silhouette', 'davies_bouldin', 'k']:
            assert math.isclose(float(row[key]), float(comparison[key]), rel_tol=1e-12, abs_tol=1e-12)
        rows.append(row)
        statuses.append(status)
    assert len({r['response_id'] for r in rows}) == 3
    assert sum(r['model_calls'] for r in rows) == 3
    assert sum(r['total_tokens'] for r in rows) == 4077

    descriptives = []
    for key, label, unit in METRICS:
        descriptives.append({'metric': key, '指标': label, '单位': unit, **stats(r[key] for r in rows)})
    by_metric = {r['metric']: r for r in descriptives}
    frequency = []
    for key, label in POLICIES.items():
        counts = Counter(display(r[key]) for r in rows)
        for value, count in sorted(counts.items()):
            frequency.append({'决策': label, '字段': key, '策略': value, '次数': count, '补充实验总数': 3,
                              '占比': count/3, '是否与首次主实验策略一致': value == display(first_policy[key])})
    signatures = Counter(json.dumps({k: r[k] for k in POLICIES}, sort_keys=True, ensure_ascii=False) for r in rows)
    baseline_signature = json.dumps(first_policy, sort_keys=True, ensure_ascii=False)
    plans = [{'完整计划': plan, '次数': count, '总数': 3, '占比': count/3, '是否与主实验完整计划一致': plan == baseline_signature}
             for plan, count in sorted(signatures.items())]
    differences = []
    for r in rows:
        diff = {'supplement_no': r['supplement_no'], 'original_run': r['original_run'],
                '完整计划与首次一致': all(r[k] == first_policy[k] for k in POLICIES)}
        for key in ['cluster_rows', 'cluster_retention', 'k', 'silhouette', 'davies_bouldin']:
            diff[key] = r[key]
            diff[key+'_first'] = float(first[key])
            diff[key+'_minus_first'] = float(r[key])-float(first[key])
        differences.append(diff)
    all_pairs = csvread(ROOT/'参照与核查/原生两两一致性_来源.csv')
    supp_pairs = [r for r in all_pairs if int(r['run_a']) > 1 and int(r['run_b']) > 1]
    first_pairs = [r for r in all_pairs if int(r['run_a']) == 1]
    assert len(supp_pairs) == len(first_pairs) == 3
    pair_stats = [{'metric': key, **stats(r[key] for r in supp_pairs)}
                  for key in ['selection_jaccard', 'native_cluster_ari_on_pair_common']]
    control = [r for r in csvread(ROOT/'参照与核查/共同样本控制指标_来源.csv') if int(r['run']) > 1]
    control_pairs = [r for r in csvread(ROOT/'参照与核查/共同样本控制ARI_来源.csv') if int(r['run_a']) > 1 and int(r['run_b']) > 1]
    assert len(control) == len(control_pairs) == 3
    assert all(int(r['common_rows']) == 7424 and int(r['k']) == 4 for r in control)
    assert all(float(r['adjusted_rand_index']) == 1 and float(r['max_abs_feature_difference']) == 0 for r in control_pairs)
    controlled_stats = [{'metric': key, **stats(r[key] for r in control)}
                        for key in ['silhouette', 'davies_bouldin', 'calinski_harabasz']]
    products = {
        '统计汇总/后三次逐次结果.csv': csvbytes(rows),
        '统计汇总/后三次数值指标描述统计.csv': csvbytes(descriptives),
        '统计汇总/后三次策略选择频次.csv': csvbytes(frequency),
        '统计汇总/后三次完整计划频次.csv': csvbytes(plans),
        '统计汇总/与首次主实验的指标对照.csv': csvbytes(differences),
        '统计汇总/后三次两两原生分群一致性.csv': csvbytes(supp_pairs),
        '统计汇总/与首次主实验的原生分群一致性.csv': csvbytes(first_pairs),
        '统计汇总/后三次配对指标描述统计.csv': csvbytes(pair_stats),
        '统计汇总/共同样本控制比较_后三次.csv': csvbytes(control),
        '统计汇总/共同样本控制ARI_后三次.csv': csvbytes(control_pairs),
        '统计汇总/共同样本控制指标描述统计.csv': csvbytes(controlled_stats)
    }
    native_rows = '\n'.join(
        f"| 补充{r['supplement_no']}（原第{r['original_run']}次） | "
        f"{'排除未观测大小' if r['size']=='drop' else '类别中位数代理'} | "
        f"{r['cluster_rows']} | {r['cluster_retention']:.2%} | {r['k']} | "
        f"{r['silhouette']:.6f} | {r['davies_bouldin']:.6f} |" for r in rows)
    desc_rows = '\n'.join(
        f"| {r['指标']} | {r['mean']:.8g} | {r['sample_variance']:.8g} | {r['sample_std']:.8g} | "
        f"{'不适用' if r['cv_percent']=='' else format(r['cv_percent'], '.3f')+'%'} | {r['单位']} |"
        for r in descriptives)
    sil, db = by_metric['silhouette'], by_metric['davies_bouldin']
    ari_stats = next(r for r in pair_stats if r['metric'] == 'native_cluster_ari_on_pair_common')
    report = f"""# 智能体稳定性补充实验：后三次

第一次运行仍为主实验，原报告及三组比较继续作为主体。本文件仅汇总后来追加的3次真实模型运行；编号为补充1/2/3，对应原第2/3/4次。首次只作基准，未计入下列均值和方差。

## 1. 目的与条件

考察同一可见输入和执行条件下的策略重复性、质量约束和结果波动。数据与6份核心源代码SHA256、依赖、模型请求名deepseek-flash、首请求正文及端点、可见聚类参数相同；聚类种子42，候选k为2至6。3次响应ID不同，各调用1次，无校验重试，共4077 token。实际账单费用未知。来源和原始记录均随文件夹保留，整理和复核不新增API调用。

## 2. 三次补充结果

| 补充编号 | 大小处理 | 聚类记录数 | 保留率 | k | 原生轮廓系数 | 原生DB指数 |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
{native_rows}

首次主实验的参照值：类别中位数代理、{int(first['cluster_rows'])}条、k={int(first['k'])}、轮廓系数{float(first['silhouette']):.6f}、DB={float(first['davies_bouldin']):.6f}。完整计划与主实验一致的是补充3（1/3）；其余两次只在大小策略上不同。首次完整结果保持在原交付项目中，此文件夹不重复放入首次全量数据。

## 3. 均值、样本方差与标准差

仅对上述3次统计。样本方差 s²=Σ(xᵢ−均值)²/(n−1)，n=3、ddof=1；标准差s=√s²，变异系数CV=100s/|均值|。均值为0时CV不适用。CSV保留未四舍五入数值，单位平方适用于方差列。

| 指标 | 均值 | 样本方差 | 样本标准差 | CV | 原指标单位 |
| --- | ---: | ---: | ---: | ---: | --- |
{desc_rows}

轮廓系数CV为{sil['cv_percent']:.3f}%，DB指数CV为{db['cv_percent']:.3f}%，可作为本批分数波动幅度的描述。保留率标准差为{100*by_metric['cluster_retention']['sample_std']:.4f}个百分点，方差{by_metric['cluster_retention']['sample_variance']:.9f}使用0至1比例的平方单位；不能混写成百分数平方。k的均值仅作离散数值描述，不作为推荐簇数。

没有预先规定稳定性的统计阈值，n=3不足以据此宣称普遍稳定；不同策略的原生训练样本和选定k不同，轮廓系数与DB的均值、方差仅用于描述整体流程输出，不直接作优劣判断，也不能证明缺失处理等效。

## 4. 哪些方面一致，哪些存在变化

- 完全重复处理：3/3选择去重；评分缺失：3/3选择不参与聚类。分类策略只报频次，不人为编码后计算方差。
- 安全与质量结果：三次均去除483条完全重复、隔离1条错位，清洗档案10357条；残留完全重复、核心非法值及聚类非法/缺失特征均为0。这些质量计数的样本方差均为0，支持本批固定安全工具与这两项模型选择执行一致，不能把固定规则的确定性全部归功于模型。
- 大小策略：2/3选择排除未观测大小，1/3选择类别中位数代理。因此大小策略与完整计划并非三次全部一致，样本量和选定k随之变化。
- 补充1与2采用同一计划，原生标签ARI=1、样本选择Jaccard=1；补充1与3、2与3的原生标签ARI均约0.724047、Jaccard均约0.834908。这里在共同记录上比较各自训练的原生标签，未控制原生k及训练总体。三对ARI均值为{ari_stats['mean']:.6f}、样本方差为{ari_stats['sample_variance']:.8f}，但三对共享运行，不能将配对值视为3个相互独立的实验样本。
- 共同7424条完整记录、相同缩放和k=4/种子42的控制重拟合，三对ARI均为1，轮廓系数与DB方差均为0；因为共同记录输入特征完全相同，该结果只支持计算流程重复性，不能验证未观测大小处理的稳定性或准确性。

## 5. 解释质量与边界

补充3（原第4次）的大小理由同时出现“不适合用中位数填充”与“因此按类别取中位数”，文字自相矛盾，实际JSON选择category_median并按该策略执行。原始理由已保留，应人工复核。drop表示保留cleaned档案但不参加聚类，不是删除整条原始记录。类别中位数只是建模代理，原始未知状态保留。

主实验与补充实验跨日；服务端内部修订号未返回，生成随机种子未固定，不能将全部差异归因于某一个采样参数。没有缺失真值，重复调用不能验证填补准确性。

## 6. 可放入报告的补充实验段落

在首次主实验之外，追加3次独立真实模型调用作稳定性补充检验。三次去重和评分缺失策略均一致，清洗档案数、异常隔离数及残留非法值等质量指标的样本方差均为0；轮廓系数为{sil['mean']:.5f}±{sil['sample_std']:.5f}，DB指数为{db['mean']:.5f}±{db['sample_std']:.5f}（均值±样本标准差，n=3）。结果支持本批安全处理与部分决策的一致性，但大小策略在排除与类别中位数代理之间变化，参与聚类样本及k相应改变，因此尚不能断言完整策略完全稳定。该补充检验不改变首次主实验的主体地位。

## 7. 复核方法

本文件夹根目录执行：

    python 复现统计.py --verify-only

该命令仅用Python标准库读取随包留存记录，校验输入SHA256并重算11张汇总表及本文，比较是否一致；不调用模型、不重新拟合聚类。去掉--verify-only可刷新统计表和本文。原流水线的全量离线重算继续使用原项目的analyze_agent_stability.py --verify-replays；上轮独立验收已对各次38份CSV做过复现，回执随附。补充运行文件内的历史绝对路径和原编号如实保留。
"""
    products['补充实验结论.md'] = report.encode('utf-8')
    for name, expected in products.items():
        path = ROOT/name
        if args.verify_only:
            assert path.read_bytes() == expected, '派生文件不一致：'+name
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(expected)
    print(json.dumps({'status': 'pass', 'mode': 'verify-only' if args.verify_only else 'regenerate',
                      'supplement_runs': [2,3,4], 'n': 3, 'ddof': 1, 'derived_files': len(products),
                      'new_api_calls': 0, 'original_calls': 3, 'original_tokens': 4077,
                      'source_files_verified': len(inputs)}, ensure_ascii=False))

if __name__ == '__main__':
    main()
